8% Paraformaldehyde for Immunofluorescence
========================================================================================================

.. sectionauthor:: lukehammond <l.hammond@uq.edu.au>

Contributed by Luke Hammond <l.hammond@uq.edu.au>

8% Paraformaldehyde for Immunofluorescence








- Add 16g paraformaldehyde to approximately 160ml water in fume hood.


- Heating on setting 4.5 whilst stirring to 50ºC.


- Once temperature reaches 50ºC, 1M NaOH until the paraformaldehyde is just dissolved.


- Make up to final volume of 200ml with water, pH to 7.2-7.4.


- Filter with 0.22µm filter.


- Aliquot in 5ml tubes, label and freeze.







This method is based, with permission, on an original protocol available `here <http://web.qbi.uq.edu.au/microscopy/?page_id=549>`_.
