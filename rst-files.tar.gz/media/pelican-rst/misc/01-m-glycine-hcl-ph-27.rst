0.1 M Glycine-HCl, pH 2.7
========================================================================================================

.. sectionauthor:: ianchinsang <chinsang@queensu.ca>

Contributed by Ian Chin-Sang <chinsang@queensu.ca>

0.1 M Glycine-HCl, pH 2.7






Requirements
------------
11.1 g Glycine-HCl
800 ml dH2O


Method
------

- Combine 11.1 g Glycine-HCl with 800 ml dH2O


- Adjust pH to 2.7 and bring volume to 1 L with dH2O








