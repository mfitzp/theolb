PHEM (500 mls) 2x 
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

PHEM (500 mls) 2x 






Requirements
------------
18.14 g Pipes
6.5 g Hepes
3.8 g EGTA
0.99 g MgSO4


Method
------

- Combine in beaker. Bring pH to pH7.0 with addition of KOH.







This method is based, with permission, on an original protocol available `here <http://www.bio.unc.edu/faculty/salmon/lab/protocolscommonbuffers.html>`_.
