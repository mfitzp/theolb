L B Broth
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

L B Broth






Requirements
------------
1 liter of ddH2O
10 grams Bacto-tryptone
5 grams Bacto-yeast Extract
5 grams NaCl


Method
------

- In 1 liter of ddH2O combine 10 grams Bacto-tryptone, 5 grams Bacto-yeast Extract and 5 grams NaCl


- Stir until dissolved.


- Autoclave for at least 15min @120C


- Once cooled below 55C add antibiotic of choice and store at 4C. Use within 2 weeks







This method is based, with permission, on an original protocol available `here <http://www.bio.unc.edu/faculty/salmon/lab/protocolscommonbuffers.html>`_.
