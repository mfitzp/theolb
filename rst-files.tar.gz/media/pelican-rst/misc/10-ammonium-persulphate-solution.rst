10% Ammonium persulphate solution
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

10% solution








- Add dH20 to Falcon tube or other suitable container for the volume. 


- Add 1g Ammonium persulphate per 10 ml water 

e.g. 50mls add 5g APS

Mix thoroughly - APS will dissolve readily.


- Solution may be stored at 4'C up to 6 months








