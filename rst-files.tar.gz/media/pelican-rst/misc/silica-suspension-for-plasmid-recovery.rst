Silica Suspension for plasmid recovery
========================================================================================================

.. sectionauthor:: ianchinsang <chinsang@queensu.ca>

Contributed by Ian Chin-Sang <chinsang@queensu.ca>

Silica Suspension for plasmid recovery








- Suspend 2-10  grams of Silica (Sigma S-5631) in 20 mls H2O


-  Allow to settle for 2 hours


- Remove milky supernatant and suspend settled silica in 20 mls H2O


- Allow to settle for 2 hours (repeat 3 times)


- Estimate volume and resuspend silica in 2 vols 6M Guanidine Hydrochloride-1M KOAc buffer, pH 5.5.







This method is based, with permission, on an original protocol available `here <http://130.15.90.245/zymolase_plasmid_recovery_from_yeast.htm>`_.
