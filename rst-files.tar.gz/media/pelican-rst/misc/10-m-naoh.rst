10 M NaOH
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

10 M NaOH






Requirements
------------
10 M NaOH Stock*
40 g NaOH
100ml distilled water


Method
------

- Add 40 g NaOH to a suitable container.  Add distilled water to make solution up to 100ml.

*Store at room temperature*






References
----------


Clare M. Waterman-Storer `Microtubule/Organelle Motility Assays <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_  (2001)
`10.1002/0471143030.cb1301s00 <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_







