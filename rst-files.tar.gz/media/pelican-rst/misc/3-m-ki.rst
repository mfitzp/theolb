3 M KI
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

3 M KI






Requirements
------------
4.98 g KI
10ml distilled water


Method
------

- Add  4.98 g KI to a suitable container.


- Add distilled water to make up to final volume of 10 ml. Store at room temperature until required.

*Store at room temperature*






References
----------


Clare M. Waterman-Storer `Microtubule/Organelle Motility Assays <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_  (2001)
`10.1002/0471143030.cb1301s00 <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_







