PBS (5x in 500 mls)
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

PBS (5x in 500 mls)


.. figure:: /images/method/1339/800px-Laboratory_glass_bottles-set.jpg
   :alt: method/1339/800px-Laboratory_glass_bottles-set.jpg






Requirements
------------
20.45 g NaCl
0.465 g KCl
10.142 g Na2HPO4*7 H2O
0.545 g KH2PO4


Method
------

- Add 500ml distilled water to a suitable container. 


- Add ingredients to water and pH to 7.2







This method is based, with permission, on an original protocol available `here <http://www.bio.unc.edu/faculty/salmon/lab/protocolscommonbuffers.html>`_.
