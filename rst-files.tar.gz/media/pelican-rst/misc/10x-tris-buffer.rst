10x Tris Buffer
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Recipe for 10x Tris Buffer, dilute for use








- Fill suitable container with 1L dH20


- Add 30g Tris, 88g NaCl and 2g KCl to the solution, mixing thoroughly until fully dissolved.


- Adjust pH to 7.5 with HCl








