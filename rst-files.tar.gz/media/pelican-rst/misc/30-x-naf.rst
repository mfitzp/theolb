30 x NaF
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

30 x NaF






Requirements
------------
378 mg NaF (0.9 M NaF)
10ml distilled water


Method
------

- Add 378 mg NaF (0.9 M NaF) to a suitable container. 



- Add distilled water up to a final volume of 10 ml 

*Store at -20oC*






References
----------


Clare M. Waterman-Storer `Microtubule/Organelle Motility Assays <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_  (2001)
`10.1002/0471143030.cb1301s00 <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_







