1M dithiothreitol (DTT)
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

1M dithiothreitol (DTT)






Requirements
------------
1.542 g dithiothreitol
10ml Distilled water


Method
------

- Add dithiothreitol to a suitable container. Make up to 10ml with distilled water.


- Aliquot in 500 ml volumes and store at -20oC for future use.

*Store at -20oC*






References
----------


Clare M. Waterman-Storer `Microtubule/Organelle Motility Assays <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_  (2001)
`10.1002/0471143030.cb1301s00 <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_







