20 x Energy Regeneration System
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

20 x Energy Regeneration System






Requirements
------------
150 mM creatine phosphate (Boehringer #127574)
2 ml of 100 mM MgATP Stock (20 mM ATP, 20 mM MgSO4)
40ml 0.5 M EGTA (2 mM EGTA)
Distilled water to 10 ml 


Method
------

- Combine ingredients in suitable beaker. Make up to 10ml with distilled water.


- Aliquot in 100 ml containers and store at -20oC

*Store at -20oC*






References
----------


Clare M. Waterman-Storer `Microtubule/Organelle Motility Assays <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_  (2001)
`10.1002/0471143030.cb1301s00 <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_







