Chrome Alum Gelatin Slide Coating
========================================================================================================

.. sectionauthor:: lukehammond <l.hammond@uq.edu.au>

Contributed by Luke Hammond <l.hammond@uq.edu.au>

Chrome Alum Gelatin Slide Coating




Clean grease-free slides are needed for the slide coating to be effective.




Requirements
------------
200ml Distilled water
0.5g Gelatin
0.05g Chromic potassium Sulphate




Method
------

- Microwave briefly to dissolve the gelatin


- Cool


- Dip clean slides and allow to drain vertically.


- Once completely dry pack into Slide boxes in a dust free environment.







This method is based, with permission, on an original protocol available `here <http://web.qbi.uq.edu.au/microscopy/?page_id=551>`_.
