Colloidal Coomassie Blue Stain
========================================================================================================

.. sectionauthor:: ianchinsang <chinsang@queensu.ca>

Contributed by Ian Chin-Sang <chinsang@queensu.ca>

Colloidal Coomassie Blue Stain for SDS-PAGE gel


.. figure:: /images/method/1436/new_pa14.jpg
   :alt: method/1436/new_pa14.jpg








- After SDS PAGE rinse Gel twice with 100 ml Distilled H20 (3 minutes each wash).


- Add Coomassie Blue working solution to Gel and stain for at least 2 hours.


- Bands should be visible without de-staining but you can de-stain with H20.





References
----------


Neumann U, Khalaf H, Rimpler M `Quantitation of electrophoretically separated proteins in the submicrogram range by dye elution. <http://www.ncbi.nlm.nih.gov/pubmed/7529171>`_ *Electrophoresis* (1994)
`pmid:7529171 <http://www.ncbi.nlm.nih.gov/pubmed/7529171>`_







