PBS (1x in 1L)
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

PBS (1x in 1L)






Requirements
------------
 8.18 g NaCl  (140 mM NaCl)
 0.186 g KCl (2.5 mM KCl)
 0.218 g KH2PO4 (1.6 mM KH2PO4)
 2.15 g Na2HPO4 (15 mM Na2HPO4) 
Distilled water to 1 liter 


Method
------

- Combine ingredients in a suitable container. Add distilled water to 1L

*Store at room temperature.*









