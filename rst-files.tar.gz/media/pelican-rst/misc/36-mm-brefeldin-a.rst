3.6 mM Brefeldin A
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

3.6 mM Brefeldin A 






Requirements
------------
10 mg Brefeldin A (available from Epicenter Technologies Madison, WI) 
12ml absolute ethanol


Method
------

- Add 10 mg Brefeldin A to suitable container.


- Add absolute ethanol up to a final volume of 12ml. Store at -20oC until required.

*Store at -20oC*






References
----------


Clare M. Waterman-Storer `Microtubule/Organelle Motility Assays <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_  (2001)
`10.1002/0471143030.cb1301s00 <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_







