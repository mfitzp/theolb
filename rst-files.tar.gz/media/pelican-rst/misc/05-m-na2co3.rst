0.5 M Na2CO3
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

0.5 M Na2CO3






Requirements
------------
531 mg Na2CO3
10ml distilled water


Method
------

- Add 531 mg Na2CO3 to a suitable container. 


- Make up to 10ml with distilled water. Store at room temperature until further use.

*Store at room temperature.*






References
----------


Clare M. Waterman-Storer `Microtubule/Organelle Motility Assays <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_  (2001)
`10.1002/0471143030.cb1301s00 <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_







