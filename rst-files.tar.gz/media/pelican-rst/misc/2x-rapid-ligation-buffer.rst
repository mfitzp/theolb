2X Rapid Ligation Buffer
========================================================================================================

.. sectionauthor:: ianchinsang <chinsang@queensu.ca>

Contributed by Ian Chin-Sang <chinsang@queensu.ca>

2X Rapid Ligation Buffer (ProMega)






Requirements
------------
60mM Tris-HCl (pH 7.8)
20mM MgCl2
20mM DTT
2mM ATP
10% polyethylene glycol


Method
------

- Combine ingredients in suitable container.







This method is based, with permission, on an original protocol available `here <http://www.promega.com/tbs/9pim822/9pim822.pdf>`_.
