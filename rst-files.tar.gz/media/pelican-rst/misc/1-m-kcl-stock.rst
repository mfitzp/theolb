1 M KCl Stock
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

1 M KCl Stock






Requirements
------------
74.55 g KCl
1L distilled water


Method
------

- Add KCl to a suitable container. Make up to 1L with distilled water. Store for further use.

*Store at room temperature*






References
----------


Clare M. Waterman-Storer `Microtubule/Organelle Motility Assays <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_  (2001)
`10.1002/0471143030.cb1301s00 <http://dx.doi.org/10.1002/0471143030.cb1301s00>`_







