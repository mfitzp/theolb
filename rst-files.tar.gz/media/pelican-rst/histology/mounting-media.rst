Mounting Media
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Mounting Media






Requirements
------------
20mM Tris pH 8.0
0.5% N-propyl gallate
90% Glycerol 


Method
------

- Combine ingredients in suitable container. Store for use.

*Store at 4oC.*








This method is based, with permission, on an original protocol available `here <http://www.bio.unc.edu/faculty/salmon/lab/protocolscommonbuffers.html>`_.
