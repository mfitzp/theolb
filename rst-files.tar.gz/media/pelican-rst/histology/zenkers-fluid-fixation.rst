Zenker&#39;s fluid fixation
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Fixation with Zenker's fluid








- Add 950ml distilled water to a suitable container


- Add 25g potassium dichromate


- Add 50g mercuric chloride


- Add 50g glacial acetic acid


- Mix thoroughly to dissolve


- Fix samples for 4-24 hours


- Following fixation wash samples overnight in running tap water prior to processing







This method is based, with permission, on an original protocol available `here <http://www.bristol.ac.uk/vetpath/cpl/histfix.htm>`_.
