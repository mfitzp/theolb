Acetic alcohol fixation
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Fixative for smears, cytospin preparations and frozen sections








- Add 3ml glacial acetic acid to 100ml 95% methanol


- Fix section in solution for 1 minute


- Rinse section in distilled water prior to staining







This method is based, with permission, on an original protocol available `here <http://www.bristol.ac.uk/vetpath/cpl/histfix.htm>`_.
