Carnoy&#39;s fluid fixation
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Fixation of samples in Carnoy's fluid








- In a fume hood pour 60ml of ethanol into a suitable container


- Add 30ml choloroform


- Add 10ml glacial acetic acid to give a total volume of 100ml


- Place tissue into fixative for 1-3 hours


- Process fixed tissues immediately or transfer to 80% alcohol for storage







This method is based, with permission, on an original protocol available `here <http://www.bristol.ac.uk/vetpath/cpl/histfix.htm>`_.
