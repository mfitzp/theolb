Silane/acetone silanized slides
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Silanized (3-aminopropyltriethoxysilane) slides to prevent sections from detaching.








- Place slides in 2% silane/acetone solution for 1 minute


- Transfer slides to 100% acetone for 1 minute


- Transfer slides to double distilled water. Agitate for 1 minute


- Replace double distilled water, and wash repeat x2 for 1 minute


- Leave slides to air dry overnight at room temperature


- Slides may be kept indefinitely covered in slide box until ready for use








