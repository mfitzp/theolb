Helly&#39;s fluid fixation
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Fixation using Helly's fluid








- To prepare stock solution add 1l distilled water to suitable container.


- Add 25g potassium dichromate.


- Add 50g mercuric chloride.


- Add 10g sodium sulphate and mix thoroughly. Store stock solution until required.


- Make up fixative just before use. 

Add 5ml formalin (40% aqueous solution of formaldehyde) to 100ml stock solution


- Fix tissues for 12-24 hours


- Wash fixed tissue for 24hours prior to processing







This method is based, with permission, on an original protocol available `here <http://www.bristol.ac.uk/vetpath/cpl/histfix.htm>`_.
