Formol sublimate fixation
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Fixation in formol sublimate








- In a fume hood pour 100ml formalin (40% aqueous solution of formaldehyde) into a suitable container


- Add 900ml saturated aqueous mercuric chloride


- Submerge tissue and fix for 4-6 hours


- Remove fixed tissue and transfer to 80% alcohol to store







This method is based, with permission, on an original protocol available `here <http://www.bristol.ac.uk/vetpath/cpl/histfix.htm>`_.
