Debug GNOME Shell
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Debug Gnome Shell, or run it from the console, either for plugin development or troubleshooting.


.. figure:: /images/method/1496/800px-GNOME_Shell.png
   :alt: method/1496/800px-GNOME_Shell.png








- Switch to the console using `Ctrl Alt F1`


- Type "w" to find your display (usually it's `:0.0`)


- Export your display (usually with `export DISPLAY=:0.0`)


- Restart gnome shell from the console by typing `gnome-shell --replace`


- Go back to your display using `Ctrl Alt F7`







This method is based, with permission, on an original protocol available `here <http://community.linuxmint.com/tutorial/view/685>`_.
