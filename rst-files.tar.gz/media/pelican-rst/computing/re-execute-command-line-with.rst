Re-execute command line with !
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Bash history expansion allows you to quickly re-run previous commands using ! and the number of the command in your history.


.. figure:: /images/method/1492/Screen Shot 2012-04-22 at 16.03.03.png
   :alt: method/1492/Screen Shot 2012-04-22 at 16.03.03.png




You can adjust the size of the history by setting the HISTSIZE variable in the shell e.g. `export HISTSIZE=1000`. You can clear the current history with `history -c`. 






Method
------

- Bash keeps a history of all commands executed in the shell and this can be referenced using the `!` command. Typing two !'s at the prompt will execute the previous command:

	$ echo "HELLO"
	HELLO
	$ !!
	echo "HELLO"
	HELLO




- The history of the bash shell can be accessed by entering `history`

	501  echo "HELLO"
	502  echo "HELLO"
	503  history

Notice that each entry has an associated number which can be used to refer to the command.


- Entering ! followed by a line number from the history will run that command

	$ !501
 	echo "HELLO"
	HELLO




- You can also search the history by using a search string to match the command instead of a number

	$ !echo
	echo "HELLO"
	HELLO









This method is based, with permission, on an original protocol available `here <http://hacktux.com/bash/fast/cli>`_.
