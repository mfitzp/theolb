Use GNOME Looking Glass for debugging
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Looking Glass is GNOME Shell's integrated inspector tool and JavaScript console useful for debugging. 


.. figure:: /images/method/1497/shortcuts-looking-glass.png
   :alt: method/1497/shortcuts-looking-glass.png








- Open the run prompt by pressing `Alt+F2`


- Enter `lg` to start Looking Glass


- Commands can be entered directly at the prompt e.g.

`global.get_window_actors()`

.. figure:: /images/step/7348/Screenshot at 2012-05-03 20:15:22.png
   :alt: step/7348/Screenshot at 2012-05-03 20:15:22.png


*Exit at any time by pressing `Esc`*








This method is based, with permission, on an original protocol available `here <http://live.gnome.org/GnomeShell/CheatSheet>`_.
