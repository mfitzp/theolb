Execute last command as root
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Re-run previously entered command as root user.








-     sudo !!

*`!!` is automatically substituted to the content of the previous command. Turning the above line into `sudo <your command here>`.*









