Reload .bash_profile without logging in again
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Update your session to new settings in .bash_profile without logging out and back in again.








- At the prompt enter: 

`source ~/.bash_profile`


- add the following line to your .bash_profile or .bash_aliases file
`alias reload='source $HOME/.bash_profile'`
after running `source ~/.bash_profile` the command `reload` will be available to do the same thing :)










