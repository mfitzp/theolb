Find all running processes of a program
========================================================================================================

.. sectionauthor:: mfitzp <martin.fitzpatrick@gmail.com>

Contributed by Martin Fitzpatrick <martin.fitzpatrick@gmail.com>

Find the pids of all instances/processes of a given program running on your system








- Open a terminal and enter `ps ax | grep "firefox"` ...replacing 'firefox' with the name of the program you are looking for.

*The columns in the output are as follows: (1) pid 'process id' (2) tty (3) process state - see `man ps` (4) process runtime (5) process command.*









